/**
 * Created by lzhan on 2017/8/25.
 */
var options={
    host:'10.40.4.97',
    port:'3306',
    user:'root',
    password:'123456',
    database:'partjob'
};

exports.options=options;