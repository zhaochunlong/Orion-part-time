/**
 * Created by Administrator on 2017/9/23 0023.
 */
exports.sql={
    addPosition:''
};