import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-title',
  templateUrl: './company-title.component.html',
  styleUrls: ['./company-title.component.css']
})
export class CompanyTitleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
