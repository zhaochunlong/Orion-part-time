import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-intention',
  templateUrl: './user-intention.component.html',
  styleUrls: ['./user-intention.component.css']
})
export class UserIntentionComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
