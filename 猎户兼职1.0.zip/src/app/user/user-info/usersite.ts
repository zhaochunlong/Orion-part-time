/**
 * Created by Administrator on 2017/9/28 0028.
 */
export class usersite {
  constructor(
    public id: number,
    public name: string,
    public sex: string,
    public age: string,
    public area:string,
    public telephone: string,
    public school: any,
    public department: string,
    public height: string,
    public width: string,
    public strong: string,
  ) {  }
}
