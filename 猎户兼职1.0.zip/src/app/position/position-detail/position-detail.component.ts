import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-position-detail',
  templateUrl: './position-detail.component.html',
  styleUrls: ['./position-detail.component.css']
})
export class PositionDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
