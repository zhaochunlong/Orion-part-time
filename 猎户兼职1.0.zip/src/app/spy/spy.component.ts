import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spy',
  templateUrl: './spy.component.html',
  styleUrls: ['./spy.component.css']
})
export class SpyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
