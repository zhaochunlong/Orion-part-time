export class Site {
  constructor(
    public id: number,
    public logo: string,
    public name: string,
    public employer: string,
    public recommend: any,
    public city:string,
    public recruit: string,
    public site: string,
    public details: string,
  ) {  }
}
