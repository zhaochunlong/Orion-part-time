export class Site {
  constructor(
    public id: number,
    public name: string,
    public datestrart: number,
    public dateend: number,
    public city:string,
    public url: any,
    public recruit: number,
    public salary: string,
    public clearing:any,
    public sex: any,
    public recommend: string,
    public details: string,
    public workingTime:any,

) {  }
}
