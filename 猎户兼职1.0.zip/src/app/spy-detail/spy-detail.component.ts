import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spy-detail',
  templateUrl: './spy-detail.component.html',
  styleUrls: ['./spy-detail.component.css']
})
export class SpyDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
